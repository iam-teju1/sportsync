import React, { useState } from 'react';
import {
  Award,
  Plus,
  Search,
  Edit2,
  Trash2,
  Phone,
  Mail,
  Shield,
  X,
  CheckCircle2,
  Clock,
  Calendar
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { Referee, RefereeStatus } from '../../types';
import { ValidateService } from '../../services/validateService';

interface RefereesViewProps {
  onOpenConfirmation: (title: string, msg: string, onConfirm: () => void) => void;
  selectedRefereeId?: string;
}

export const RefereesView: React.FC<RefereesViewProps> = ({ onOpenConfirmation, selectedRefereeId }) => {
  const { referees, matches, teams, venues, userRole, addReferee, updateReferee, deleteReferee } = useTournament();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRef, setEditingRef] = useState<Referee | null>(null);
  const [selectedRefForSchedule, setSelectedRefForSchedule] = useState<Referee | null>(
    selectedRefereeId ? referees.find(r => r.id === selectedRefereeId) || referees[0] || null : referees[0] || null
  );

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    experience: 5,
    phone: '',
    email: '',
    status: 'Active' as RefereeStatus
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredReferees = referees.filter(r =>
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.phone.includes(searchTerm) ||
    r.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openAddModal = () => {
    setEditingRef(null);
    setFormData({
      id: `RF-0${referees.length + 1}`,
      name: '',
      experience: 6,
      phone: '+81-3-5555-3388',
      email: '',
      status: 'Active'
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const openEditModal = (ref: Referee) => {
    setEditingRef(ref);
    setFormData({
      id: ref.id,
      name: ref.name,
      experience: ref.experience,
      phone: ref.phone,
      email: ref.email,
      status: ref.status
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRef) {
      const updated: Referee = {
        ...editingRef,
        ...formData
      };
      const val = ValidateService.validateReferee(updated, referees, true);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await updateReferee(updated);
      if (res.success) setIsModalOpen(false);
    } else {
      const val = ValidateService.validateReferee(formData, referees, false);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await addReferee(formData);
      if (res.success) setIsModalOpen(false);
    }
  };

  const handleDelete = (ref: Referee) => {
    onOpenConfirmation(
      'Remove Referee Record',
      `Are you sure you want to remove official ${ref.name}? They must not have active upcoming match assignments.`,
      () => deleteReferee(ref.id)
    );
  };

  const refereeMatches = selectedRefForSchedule
    ? matches.filter(m => m.refereeId === selectedRefForSchedule.id)
    : [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <Award className="w-6 h-6 text-rose-400" />
            Tournament Officiating Referees
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Certified referees panel, experience qualifications, contact profiles, and officiating rosters.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search referee name, email..."
              className="pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 w-52 sm:w-60"
            />
          </div>

          {userRole === 'ADMIN' && (
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Referee
            </button>
          )}
        </div>
      </div>

      {/* Referees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredReferees.map(ref => {
          const assignedMatches = matches.filter(m => m.refereeId === ref.id).length;
          const isSelected = selectedRefForSchedule?.id === ref.id;

          return (
            <div
              key={ref.id}
              onClick={() => setSelectedRefForSchedule(ref)}
              className={`p-5 rounded-2xl bg-slate-900/90 border transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between ${
                isSelected ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 font-mono">{ref.id}</span>
                    <h3 className="text-base font-bold text-white tracking-tight mt-0.5">{ref.name}</h3>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      ref.status === 'Active'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : ref.status === 'On Leave'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}
                  >
                    {ref.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-400 mb-4">
                  <p className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span>Experience: <strong className="text-white">{ref.experience} Years</strong></span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{ref.email}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{ref.phone}</span>
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center text-xs">
                  <span className="text-slate-400">Assigned Matches: </span>
                  <strong className="text-rose-400 font-bold">{assignedMatches} Fixtures</strong>
                </div>
              </div>

              {userRole === 'ADMIN' && (
                <div className="flex items-center justify-end gap-1.5 pt-3 mt-4 border-t border-slate-800">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      openEditModal(ref);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      handleDelete(ref);
                    }}
                    className="p-1.5 rounded-lg text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Referee Officiating Schedule */}
      {selectedRefForSchedule && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-rose-400" />
                Officiating Assignments: {selectedRefForSchedule.name}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Schedule of matches assigned to this referee. Double booking prevention guarantees no overlapping slots.
              </p>
            </div>
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 self-start">
              {refereeMatches.length} Assigned Fixtures
            </span>
          </div>

          <div className="space-y-2.5">
            {refereeMatches.length === 0 ? (
              <p className="text-xs text-slate-500 py-8 text-center">
                This referee currently has no assigned fixtures.
              </p>
            ) : (
              refereeMatches.map(m => {
                const home = teams.find(t => t.id === m.homeTeamId)?.name;
                const away = teams.find(t => t.id === m.awayTeamId)?.name;
                const v = venues.find(vn => vn.id === m.venueId)?.name;

                return (
                  <div
                    key={m.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition-colors text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 font-mono font-bold text-rose-400">
                        {m.date} • {m.time}
                      </div>
                      <span className="font-semibold text-white">
                        {home} vs {away}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">Venue: {v}</span>
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          m.status === 'Completed'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {m.status}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative animate-slide-up">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Award className="w-5 h-5 text-rose-400" />
              {editingRef ? 'Edit Referee Profile' : 'Enroll New Match Official'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Referee ID *
                  </label>
                  <input
                    type="text"
                    value={formData.id}
                    disabled={!!editingRef}
                    onChange={e => setFormData({ ...formData, id: e.target.value })}
                    placeholder="RF-05"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500 disabled:opacity-50"
                  />
                  {formErrors.id && <p className="text-[11px] text-rose-400 mt-1">{formErrors.id}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Experience (Years) *
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.experience}
                    onChange={e => setFormData({ ...formData, experience: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500"
                  />
                  {formErrors.experience && <p className="text-[11px] text-rose-400 mt-1">{formErrors.experience}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Hiroshi Ito"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500"
                />
                {formErrors.name && <p className="text-[11px] text-rose-400 mt-1">{formErrors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="referee@sportsync.jp"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500"
                  />
                  {formErrors.email && <p className="text-[11px] text-rose-400 mt-1">{formErrors.email}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1-555-019-2831"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500"
                  />
                  {formErrors.phone && <p className="text-[11px] text-rose-400 mt-1">{formErrors.phone}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Officiating Status
                </label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as RefereeStatus })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="Active">Active</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Suspended">Suspended</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 shadow-lg"
                >
                  {editingRef ? 'Save Changes' : 'Enroll Referee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
