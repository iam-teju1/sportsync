import React from 'react';
import { Trophy, Download, Award, Shield, Flame } from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { ReportService } from '../../services/reportService';

export const StandingsView: React.FC = () => {
  const { standings, teams, matches, addToast } = useTournament();

  const handleExportCSV = () => {
    const report = ReportService.generatePointsTableReport(teams, matches);
    ReportService.exportToCSV('SportSync_Points_Table', report.headers, report.rows);
    addToast('success', 'Export Completed', 'Points table exported as CSV file.');
  };

  const handleExportPDF = () => {
    const report = ReportService.generatePointsTableReport(teams, matches);
    ReportService.exportToPDF(
      report.title,
      report.subtitle,
      report.headers,
      report.rows,
      'SportSync_Points_Table'
    );
    addToast('success', 'Export Completed', 'Official points table generated as PDF document.');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
              <Trophy className="w-6 h-6 text-amber-400" />
              Official Tournament Standings
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
              Live Auto-Sync
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Standard Scoring: <strong>Win = 3 Pts</strong> • <strong>Draw = 1 Pt</strong> • <strong>Loss = 0 Pts</strong>. Tiebreakers: Goal Difference, then Goals Scored.
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" /> CSV
          </button>
          <button
            onClick={handleExportPDF}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-950/50 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" /> PDF Table
          </button>
        </div>
      </div>

      {/* Standings Table Card */}
      <div className="overflow-hidden rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <th className="py-3.5 px-4 text-center w-14">#</th>
                <th className="py-3.5 px-4">Club / Team</th>
                <th className="py-3.5 px-3 text-center">P</th>
                <th className="py-3.5 px-3 text-center">W</th>
                <th className="py-3.5 px-3 text-center">D</th>
                <th className="py-3.5 px-3 text-center">L</th>
                <th className="py-3.5 px-3 text-center hidden md:table-cell">GF</th>
                <th className="py-3.5 px-3 text-center hidden md:table-cell">GA</th>
                <th className="py-3.5 px-3 text-center">GD</th>
                <th className="py-3.5 px-4 text-center font-black text-white">PTS</th>
                <th className="py-3.5 px-4 text-center hidden sm:table-cell">Form</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs sm:text-sm">
              {standings.map((row, idx) => {
                const isChampion = row.rank === 1;
                const isRunnerUp = row.rank === 2;
                const isPlayoffSpot = row.rank <= 4;

                return (
                  <tr
                    key={row.teamId}
                    className={`hover:bg-slate-800/40 transition-colors ${
                      isChampion ? 'bg-amber-500/5' : isPlayoffSpot ? 'bg-emerald-500/[0.02]' : ''
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-4 px-4 text-center">
                      <div className="flex items-center justify-center">
                        {isChampion ? (
                          <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 font-extrabold flex items-center justify-center border border-amber-500/40 text-xs">
                            1
                          </span>
                        ) : isRunnerUp ? (
                          <span className="w-6 h-6 rounded-full bg-slate-400/20 text-slate-300 font-bold flex items-center justify-center border border-slate-400/40 text-xs">
                            2
                          </span>
                        ) : (
                          <span className="text-slate-400 font-mono text-xs">{row.rank}</span>
                        )}
                      </div>
                    </td>

                    {/* Team Name */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={row.teamLogo}
                          alt={row.teamName}
                          className="w-8 h-8 rounded-lg object-cover bg-slate-800 border border-slate-700 shrink-0"
                          onError={e => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=64';
                          }}
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white tracking-tight">{row.teamName}</span>
                            {isChampion && (
                              <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                1st
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400">ID: {row.teamId}</span>
                        </div>
                      </div>
                    </td>

                    {/* Stats */}
                    <td className="py-4 px-3 text-center text-slate-300 font-medium">{row.played}</td>
                    <td className="py-4 px-3 text-center text-emerald-400 font-semibold">{row.won}</td>
                    <td className="py-4 px-3 text-center text-slate-400">{row.drawn}</td>
                    <td className="py-4 px-3 text-center text-rose-400">{row.lost}</td>
                    <td className="py-4 px-3 text-center text-slate-400 hidden md:table-cell">{row.goalsFor}</td>
                    <td className="py-4 px-3 text-center text-slate-400 hidden md:table-cell">{row.goalsAgainst}</td>
                    <td className="py-4 px-3 text-center font-mono font-medium">
                      <span className={row.goalDifference > 0 ? 'text-emerald-400' : row.goalDifference < 0 ? 'text-rose-400' : 'text-slate-400'}>
                        {row.goalDifference > 0 ? `+${row.goalDifference}` : row.goalDifference}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="text-sm font-black text-white px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        {row.points}
                      </span>
                    </td>

                    {/* Form Guide */}
                    <td className="py-4 px-4 text-center hidden sm:table-cell">
                      <div className="flex items-center justify-center gap-1">
                        {row.form.length === 0 ? (
                          <span className="text-slate-500 text-xs">-</span>
                        ) : (
                          row.form.map((res, i) => (
                            <span
                              key={i}
                              className={`w-5 h-5 rounded-md text-[10px] font-bold flex items-center justify-center ${
                                res === 'W'
                                  ? 'bg-emerald-500 text-white'
                                  : res === 'D'
                                  ? 'bg-slate-600 text-white'
                                  : 'bg-rose-500 text-white'
                              }`}
                            >
                              {res}
                            </span>
                          ))
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Legend Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span>Championship Leader</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Top 4 Playoff Qualifier</span>
            </div>
          </div>
          <div>
            Points Rule: 3 Pts for Win • 1 Pt for Draw • 0 Pts for Loss
          </div>
        </div>
      </div>
    </div>
  );
};
