import React, { useState } from 'react';
import { TournamentProvider, useTournament } from './context/TournamentContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { ConfirmationModal } from './components/common/ConfirmationModal';
import { ToastContainer } from './components/common/ToastContainer';
import { SupabaseConfigModal } from './components/settings/SupabaseConfigModal';

// Views
import { DashboardView } from './components/dashboard/DashboardView';
import { StandingsView } from './components/standings/StandingsView';
import { MatchesView } from './components/matches/MatchesView';
import { TeamsView } from './components/teams/TeamsView';
import { PlayersView } from './components/players/PlayersView';
import { VenuesView } from './components/venues/VenuesView';
import { RefereesView } from './components/referees/RefereesView';
import { ReportsView } from './components/reports/ReportsView';
import { AnalyticsView } from './components/analytics/AnalyticsView';

const AppContent: React.FC = () => {
  const { isLoading } = useTournament();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSupabaseOpen, setIsSupabaseOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedEntityId, setSelectedEntityId] = useState<string | undefined>(undefined);

  // Confirmation Modal state
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  const openConfirmation = (title: string, message: string, onConfirm: () => void) => {
    setConfirmConfig({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmConfig(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleNavigate = (tab: string, entityId?: string) => {
    setActiveTab(tab);
    setSelectedEntityId(entityId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center animate-pulse mb-4">
          <span className="text-emerald-400 font-extrabold text-lg">SS</span>
        </div>
        <p className="text-sm font-semibold text-white tracking-wider">Loading SportSync Database...</p>
        <p className="text-xs text-slate-500 mt-1">Initializing permanent relational store and standings engine</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col transition-colors duration-200">
      {/* Sticky Navigation Bar */}
      <Navbar
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenSupabase={() => setIsSupabaseOpen(true)}
        onOpenConfirmation={openConfirmation}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Responsive Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={tab => {
            setActiveTab(tab);
            setSelectedEntityId(undefined);
          }}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
          onOpenSupabase={() => setIsSupabaseOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-full">
          {activeTab === 'dashboard' && (
            <DashboardView
              onNavigate={handleNavigate}
              onOpenSchedule={() => setActiveTab('matches')}
              onOpenRecordScore={() => setActiveTab('matches')}
              onOpenAddTeam={() => setActiveTab('teams')}
            />
          )}

          {activeTab === 'standings' && <StandingsView />}

          {activeTab === 'matches' && (
            <MatchesView
              onOpenConfirmation={openConfirmation}
              selectedMatchId={selectedEntityId}
            />
          )}

          {activeTab === 'teams' && (
            <TeamsView
              onOpenConfirmation={openConfirmation}
              selectedTeamId={selectedEntityId}
            />
          )}

          {activeTab === 'players' && (
            <PlayersView
              onOpenConfirmation={openConfirmation}
              selectedPlayerId={selectedEntityId}
            />
          )}

          {activeTab === 'venues' && (
            <VenuesView
              onOpenConfirmation={openConfirmation}
              selectedVenueId={selectedEntityId}
            />
          )}

          {activeTab === 'referees' && (
            <RefereesView
              onOpenConfirmation={openConfirmation}
              selectedRefereeId={selectedEntityId}
            />
          )}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'analytics' && <AnalyticsView />}
        </main>
      </div>

      {/* Global Modals & Toast Manager */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={handleNavigate}
      />

      <SupabaseConfigModal
        isOpen={isSupabaseOpen}
        onClose={() => setIsSupabaseOpen(false)}
      />

      <ConfirmationModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <TournamentProvider>
      <AppContent />
    </TournamentProvider>
  );
}
