import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertCircle, Copy, ExternalLink, X, RefreshCw, UploadCloud } from 'lucide-react';
import { storageService, SupabaseConfig } from '../../services/storageService';
import { useTournament } from '../../context/TournamentContext';

interface SupabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({ isOpen, onClose }) => {
  const { addToast, isSupabaseConnected, refreshData, teams, players, venues, referees, matches, activities } = useTournament();
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusType, setStatusType] = useState<'success' | 'error' | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [activeTab, setActiveTab] = useState<'settings' | 'schema'>('settings');

  useEffect(() => {
    if (isOpen) {
      storageService.getSupabaseConfig().then(cfg => {
        setUrl(cfg.url || '');
        setAnonKey(cfg.anonKey || '');
      });
      setStatusMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTestAndSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !anonKey.trim()) {
      setStatusType('error');
      setStatusMessage('Please enter both Supabase URL and Anon Public Key.');
      return;
    }

    setIsTesting(true);
    setStatusMessage(null);

    const test = await storageService.testConnection(url.trim(), anonKey.trim());
    if (test.success) {
      await storageService.setSupabaseConfig(url.trim(), anonKey.trim());
      setStatusType('success');
      setStatusMessage(test.message);
      addToast('success', 'Database Connected', 'Supabase PostgreSQL connected successfully!');
      await refreshData();
    } else {
      setStatusType('error');
      setStatusMessage(test.message);
      addToast('error', 'Database Connection Failed', test.message);
    }
    setIsTesting(false);
  };

  const handleSyncToSupabase = async () => {
    if (!url.trim() || !anonKey.trim()) {
      addToast('warning', 'Missing Credentials', 'Configure your Supabase connection first.');
      return;
    }
    setIsSyncing(true);
    try {
      await storageService.setSupabaseConfig(url.trim(), anonKey.trim());
      await storageService.saveAllData({ teams, players, venues, referees, matches, activities });
      addToast('success', 'Sync Completed', 'All tournament tables and relational records saved to Supabase!');
      setStatusType('success');
      setStatusMessage('Data synchronized successfully to Supabase PostgreSQL cloud!');
    } catch (err: any) {
      addToast('error', 'Sync Failed', err.message || 'Could not sync records');
    } finally {
      setIsSyncing(false);
    }
  };

  const copySchemaSQL = () => {
    const sql = `-- SportSync Supabase PostgreSQL Schema
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS teams (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    coach VARCHAR(100) NOT NULL,
    captain VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    logo TEXT,
    description TEXT,
    registered_date DATE DEFAULT CURRENT_DATE,
    wins INTEGER DEFAULT 0,
    draws INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    goals_for INTEGER DEFAULT 0,
    goals_against INTEGER DEFAULT 0,
    points INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS venues (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    capacity INTEGER NOT NULL CHECK (capacity > 0),
    availability VARCHAR(50) DEFAULT 'Available',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS referees (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    experience INTEGER NOT NULL CHECK (experience >= 0),
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(150) NOT NULL,
    assigned_matches INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'Active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS players (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INTEGER NOT NULL CHECK (age >= 14 AND age <= 60),
    gender VARCHAR(20) NOT NULL,
    position VARCHAR(50) NOT NULL,
    jersey_number INTEGER NOT NULL,
    team_id VARCHAR(50) REFERENCES teams(id) ON DELETE SET NULL,
    goals INTEGER DEFAULT 0,
    assists INTEGER DEFAULT 0,
    matches_played INTEGER DEFAULT 0,
    yellow_cards INTEGER DEFAULT 0,
    red_cards INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'Active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS matches (
    id VARCHAR(50) PRIMARY KEY,
    home_team_id VARCHAR(50) NOT NULL REFERENCES teams(id) ON DELETE RESTRICT,
    away_team_id VARCHAR(50) NOT NULL REFERENCES teams(id) ON DELETE RESTRICT,
    venue_id VARCHAR(50) NOT NULL REFERENCES venues(id) ON DELETE RESTRICT,
    referee_id VARCHAR(50) NOT NULL REFERENCES referees(id) ON DELETE RESTRICT,
    match_date DATE NOT NULL,
    match_time VARCHAR(10) NOT NULL,
    status VARCHAR(50) DEFAULT 'Scheduled',
    home_score INTEGER DEFAULT 0,
    away_score INTEGER DEFAULT 0,
    winner_team_id VARCHAR(50) REFERENCES teams(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT chk_different_teams CHECK (home_team_id <> away_team_id)
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_type VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE referees ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_teams" ON teams FOR ALL USING (true);
CREATE POLICY "public_venues" ON venues FOR ALL USING (true);
CREATE POLICY "public_referees" ON referees FOR ALL USING (true);
CREATE POLICY "public_players" ON players FOR ALL USING (true);
CREATE POLICY "public_matches" ON matches FOR ALL USING (true);
CREATE POLICY "public_activity_logs" ON activity_logs FOR ALL USING (true);`;

    navigator.clipboard.writeText(sql);
    addToast('success', 'SQL Copied', 'Paste into your Supabase project SQL Editor to create tables.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative flex flex-col max-h-[90vh] overflow-hidden animate-slide-up">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              Supabase PostgreSQL Database
              {isSupabaseConnected ? (
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Connected
                </span>
              ) : (
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1">
                  IndexedDB Permanent Active
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Production relational database configuration for tournament entities.
            </p>
          </div>
        </div>

        {/* Tab selection */}
        <div className="flex gap-2 border-b border-slate-800 pb-3 mb-4">
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'settings'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-900/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Connection Settings
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'schema'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-900/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            PostgreSQL Relational Schema (SQL)
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto pr-1">
          {activeTab === 'settings' ? (
            <form onSubmit={handleTestAndSave} className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 font-semibold text-emerald-400">
                  <Database className="w-4 h-4" />
                  Dual-Driver Permanent Storage Architecture
                </div>
                <p>
                  SportSync is pre-configured with <strong>zero LocalStorage usage</strong>. All teams, players, venues, referees, matches, and activities are permanently preserved in relational PostgreSQL tables on Supabase or local persistent browser IndexedDB.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Supabase Project URL
                </label>
                <input
                  type="url"
                  value={url}
                  onChange={e => setUrl(e.target.value)}
                  placeholder="https://xyzproject.supabase.co"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Supabase Anon Public API Key
                </label>
                <input
                  type="password"
                  value={anonKey}
                  onChange={e => setAnonKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              {statusMessage && (
                <div
                  className={`p-3.5 rounded-xl text-xs flex items-start gap-2.5 border ${
                    statusType === 'success'
                      ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                      : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
                  }`}
                >
                  {statusType === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  )}
                  <span>{statusMessage}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3">
                <button
                  type="button"
                  onClick={handleSyncToSupabase}
                  disabled={isSyncing}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-500/40 hover:bg-emerald-900/50 transition-all flex items-center gap-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  {isSyncing ? 'Syncing Tables...' : 'Sync Local Data to Supabase'}
                </button>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    disabled={isTesting}
                    className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-900/40 transition-all flex items-center gap-2"
                  >
                    {isTesting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Testing...
                      </>
                    ) : (
                      'Save & Test Supabase'
                    )}
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">
                  Run this SQL in Supabase SQL Editor:
                </span>
                <button
                  onClick={copySchemaSQL}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-400 bg-emerald-950 border border-emerald-500/30 hover:bg-emerald-900/40 transition-colors flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" /> Copy SQL Schema
                </button>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 max-h-80 overflow-y-auto leading-relaxed select-all">
                <p className="text-emerald-400 mb-2">-- Relational Tables Created:</p>
                <p>1. teams (id PK, name, coach, captain, city, stats, points)</p>
                <p>2. venues (id PK, name, address, city, capacity, availability)</p>
                <p>3. referees (id PK, name, experience, phone, email, assigned)</p>
                <p>4. players (id PK, name, age, team_id FK, position, goals, assists)</p>
                <p>5. matches (id PK, home_team_id FK, away_team_id FK, venue_id FK, referee_id FK, scores, status)</p>
                <p>6. activity_logs (id UUID PK, action_type, title, description, timestamp)</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
