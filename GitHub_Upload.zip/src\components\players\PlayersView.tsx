import React, { useState } from 'react';
import {
  UserCheck,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  Filter,
  X,
  Shield,
  Activity,
  Award
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { Player, PlayerPosition, PlayerStatus } from '../../types';
import { ValidateService } from '../../services/validateService';

interface PlayersViewProps {
  onOpenConfirmation: (title: string, msg: string, onConfirm: () => void) => void;
  selectedPlayerId?: string;
}

export const PlayersView: React.FC<PlayersViewProps> = ({ onOpenConfirmation, selectedPlayerId }) => {
  const { players, teams, userRole, addPlayer, updatePlayer, deletePlayer } = useTournament();
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState<string>('ALL');
  const [teamFilter, setTeamFilter] = useState<string>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [viewingPlayer, setViewingPlayer] = useState<Player | null>(
    selectedPlayerId ? players.find(p => p.id === selectedPlayerId) || null : null
  );

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    age: 24,
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    position: 'Forward' as PlayerPosition,
    jerseyNumber: 10,
    teamId: teams[0]?.id || '',
    status: 'Active' as PlayerStatus
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredPlayers = players.filter(p => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.jerseyNumber.toString() === searchTerm;

    const matchesPos = positionFilter === 'ALL' || p.position === positionFilter;
    const matchesTeam = teamFilter === 'ALL' || p.teamId === teamFilter;

    return matchesSearch && matchesPos && matchesTeam;
  });

  const openAddModal = () => {
    setEditingPlayer(null);
    setFormData({
      id: `PL-${players.length + 1 < 10 ? '0' : ''}${players.length + 1}`,
      name: '',
      age: 24,
      gender: 'Male',
      position: 'Forward',
      jerseyNumber: 9,
      teamId: teams[0]?.id || '',
      status: 'Active'
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const openEditModal = (player: Player) => {
    setEditingPlayer(player);
    setFormData({
      id: player.id,
      name: player.name,
      age: player.age,
      gender: player.gender,
      position: player.position,
      jerseyNumber: player.jerseyNumber,
      teamId: player.teamId,
      status: player.status
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPlayer) {
      const updated: Player = {
        ...editingPlayer,
        ...formData
      };
      const val = ValidateService.validatePlayer(updated, players, teams, true);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await updatePlayer(updated);
      if (res.success) setIsModalOpen(false);
    } else {
      const val = ValidateService.validatePlayer(formData, players, teams, false);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await addPlayer(formData);
      if (res.success) setIsModalOpen(false);
    }
  };

  const handleDelete = (player: Player) => {
    onOpenConfirmation(
      'Delete Player',
      `Are you sure you want to remove ${player.name} from the tournament roster? This action cannot be undone.`,
      () => deletePlayer(player.id)
    );
  };

  const getPositionBadge = (pos: PlayerPosition) => {
    switch (pos) {
      case 'Forward':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'Midfielder':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'Defender':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'Goalkeeper':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <UserCheck className="w-6 h-6 text-cyan-400" />
            Tournament Players & Squads
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Registered athlete profiles, individual match metrics, disciplinary records, and squad allocations.
          </p>
        </div>

        {userRole === 'ADMIN' && (
          <button
            onClick={openAddModal}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all self-start sm:self-center shrink-0"
          >
            <Plus className="w-4 h-4" /> Add Player
          </button>
        )}
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search player name, jersey #..."
              className="pl-9 pr-4 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-52 sm:w-60"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Position:</span>
            <select
              value={positionFilter}
              onChange={e => setPositionFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="ALL">All Positions</option>
              <option value="Forward">Forward</option>
              <option value="Midfielder">Midfielder</option>
              <option value="Defender">Defender</option>
              <option value="Goalkeeper">Goalkeeper</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Team:</span>
            <select
              value={teamFilter}
              onChange={e => setTeamFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="ALL">All Teams</option>
              {teams.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <span className="text-slate-400 font-medium">
          Showing <strong>{filteredPlayers.length}</strong> athletes
        </span>
      </div>

      {/* Players Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredPlayers.map(player => {
          const team = teams.find(t => t.id === player.teamId);

          return (
            <div
              key={player.id}
              className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 shadow-lg hover:border-cyan-500/40 transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center font-mono font-black text-sm text-cyan-400 group-hover:scale-105 transition-transform">
                      #{player.jerseyNumber}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {player.name}
                      </h3>
                      <p className="text-[11px] text-slate-400 truncate max-w-[130px]">
                        {team ? team.name : 'Unassigned'}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPositionBadge(
                      player.position
                    )}`}
                  >
                    {player.position}
                  </span>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-3 gap-1.5 p-2 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center mb-3">
                  <div>
                    <span className="text-[9px] text-slate-500 uppercase block font-semibold">Goals</span>
                    <span className="text-xs font-bold text-emerald-400">{player.goals}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 uppercase block font-semibold">Assists</span>
                    <span className="text-xs font-bold text-cyan-400">{player.assists}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 uppercase block font-semibold">Matches</span>
                    <span className="text-xs font-bold text-slate-200">{player.matchesPlayed}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 mb-2">
                  <span>Age: <strong className="text-white">{player.age}</strong></span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-amber-400 font-bold">{player.yellowCards} YC</span>
                    <span>•</span>
                    <span className="text-rose-400 font-bold">{player.redCards} RC</span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="flex items-center justify-between pt-2.5 border-t border-slate-800">
                <button
                  onClick={() => setViewingPlayer(player)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition-colors"
                >
                  <Eye className="w-3 h-3 text-cyan-400" /> Profile
                </button>

                {userRole === 'ADMIN' && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(player)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                      title="Edit Player"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(player)}
                      className="p-1.5 rounded-lg text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                      title="Delete Player"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Player Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-cyan-400" />
              {editingPlayer ? 'Edit Athlete Record' : 'Register New Athlete'}
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              A player belongs to exactly one team in accordance with tournament eligibility rules.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Player ID *
                  </label>
                  <input
                    type="text"
                    value={formData.id}
                    disabled={!!editingPlayer}
                    onChange={e => setFormData({ ...formData, id: e.target.value })}
                    placeholder="PL-21"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
                  />
                  {formErrors.id && <p className="text-[11px] text-rose-400 mt-1">{formErrors.id}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Jersey Number *
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={formData.jerseyNumber}
                    onChange={e => setFormData({ ...formData, jerseyNumber: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                  {formErrors.jerseyNumber && <p className="text-[11px] text-rose-400 mt-1">{formErrors.jerseyNumber}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Shoyo Hinata"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                {formErrors.name && <p className="text-[11px] text-rose-400 mt-1">{formErrors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Age * (14 - 60)
                  </label>
                  <input
                    type="number"
                    min={14}
                    max={60}
                    value={formData.age}
                    onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                  {formErrors.age && <p className="text-[11px] text-rose-400 mt-1">{formErrors.age}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Gender
                  </label>
                  <select
                    value={formData.gender}
                    onChange={e => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Assigned Team *
                  </label>
                  <select
                    value={formData.teamId}
                    onChange={e => setFormData({ ...formData, teamId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    {teams.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.teamId && <p className="text-[11px] text-rose-400 mt-1">{formErrors.teamId}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Position *
                  </label>
                  <select
                    value={formData.position}
                    onChange={e => setFormData({ ...formData, position: e.target.value as PlayerPosition })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Forward">Forward</option>
                    <option value="Midfielder">Midfielder</option>
                    <option value="Defender">Defender</option>
                    <option value="Goalkeeper">Goalkeeper</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Player Status
                </label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as PlayerStatus })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="Active">Active</option>
                  <option value="Injured">Injured</option>
                  <option value="Suspended">Suspended</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 shadow-lg shadow-cyan-950/50"
                >
                  {editingPlayer ? 'Save Changes' : 'Register Athlete'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Player Profile Modal */}
      {viewingPlayer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up space-y-5">
            <button
              onClick={() => setViewingPlayer(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-950 border-2 border-cyan-500/50 flex items-center justify-center font-mono font-black text-2xl text-cyan-400 shrink-0">
                #{viewingPlayer.jerseyNumber}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{viewingPlayer.name}</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {teams.find(t => t.id === viewingPlayer.teamId)?.name || 'Unassigned'} • ID: {viewingPlayer.id}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPositionBadge(viewingPlayer.position)}`}>
                    {viewingPlayer.position}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                    Age {viewingPlayer.age} • {viewingPlayer.gender}
                  </span>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-3 gap-2.5 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Goals</span>
                <p className="text-xl font-bold text-emerald-400">{viewingPlayer.goals}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Assists</span>
                <p className="text-xl font-bold text-cyan-400">{viewingPlayer.assists}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Caps</span>
                <p className="text-xl font-bold text-slate-200">{viewingPlayer.matchesPlayed}</p>
              </div>
            </div>

            {/* Disciplinary & Status */}
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Match Eligibility:</span>
                <span className="font-semibold text-emerald-400">{viewingPlayer.status}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Disciplinary Record:</span>
                <span className="text-slate-200">
                  <strong className="text-amber-400">{viewingPlayer.yellowCards}</strong> Yellow Cards • <strong className="text-rose-400">{viewingPlayer.redCards}</strong> Red Cards
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setViewingPlayer(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
