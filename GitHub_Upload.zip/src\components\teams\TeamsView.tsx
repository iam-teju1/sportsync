import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  Shield,
  MapPin,
  Calendar,
  X,
  Award,
  CheckCircle2
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { Team } from '../../types';
import { ValidateService } from '../../services/validateService';

interface TeamsViewProps {
  onOpenConfirmation: (title: string, msg: string, onConfirm: () => void) => void;
  selectedTeamId?: string;
}

export const TeamsView: React.FC<TeamsViewProps> = ({ onOpenConfirmation, selectedTeamId }) => {
  const { teams, players, matches, userRole, addTeam, updateTeam, deleteTeam } = useTournament();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeam, setEditingTeam] = useState<Team | null>(null);
  const [viewingTeam, setViewingTeam] = useState<Team | null>(
    selectedTeamId ? teams.find(t => t.id === selectedTeamId) || null : null
  );

  // Form State
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    coach: '',
    captain: '',
    city: '',
    logo: '',
    description: '',
    registeredDate: new Date().toISOString().substring(0, 10)
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredTeams = teams.filter(t =>
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.coach.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.captain.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openAddModal = () => {
    setEditingTeam(null);
    setFormData({
      id: `TM-0${teams.length + 1}`,
      name: '',
      coach: '',
      captain: '',
      city: '',
      logo: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=128',
      description: '',
      registeredDate: new Date().toISOString().substring(0, 10)
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const openEditModal = (team: Team) => {
    setEditingTeam(team);
    setFormData({
      id: team.id,
      name: team.name,
      coach: team.coach,
      captain: team.captain,
      city: team.city,
      logo: team.logo,
      description: team.description,
      registeredDate: team.registeredDate
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTeam) {
      const updated: Team = {
        ...editingTeam,
        ...formData
      };
      const val = ValidateService.validateTeam(updated, teams, true);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await updateTeam(updated);
      if (res.success) setIsModalOpen(false);
    } else {
      const val = ValidateService.validateTeam(formData, teams, false);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await addTeam(formData);
      if (res.success) setIsModalOpen(false);
    }
  };

  const handleDelete = (team: Team) => {
    const linkedPlayers = players.filter(p => p.teamId === team.id).length;
    const linkedMatches = matches.filter(m => m.homeTeamId === team.id || m.awayTeamId === team.id).length;

    let msg = `Are you sure you want to delete ${team.name}?`;
    if (linkedPlayers > 0 || linkedMatches > 0) {
      msg = `Warning: ${team.name} currently has ${linkedPlayers} registered player(s) and ${linkedMatches} match(es). Deleting this team will unassign all linked players and remove schedule references. Proceed?`;
    }

    onOpenConfirmation('Delete Team', msg, () => {
      deleteTeam(team.id, true);
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <Users className="w-6 h-6 text-emerald-400" />
            Tournament Teams Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage clubs, coaching staffs, captains, and team rosters across the league.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search by name, coach, city..."
              className="pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 w-56 sm:w-64"
            />
          </div>

          {userRole === 'ADMIN' && (
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Team
            </button>
          )}
        </div>
      </div>

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTeams.map(team => {
          const squad = players.filter(p => p.teamId === team.id);
          const teamMatches = matches.filter(m => m.homeTeamId === team.id || m.awayTeamId === team.id);

          return (
            <div
              key={team.id}
              className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl hover:border-emerald-500/40 transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={team.logo}
                      alt={team.name}
                      className="w-12 h-12 rounded-xl object-cover bg-slate-800 border border-slate-700 shrink-0"
                      onError={e => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=128';
                      }}
                    />
                    <div>
                      <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">
                        {team.name}
                      </h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-emerald-400" /> {team.city} • ID: {team.id}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    {team.points} PTS
                  </span>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {team.description || 'No description provided.'}
                </p>

                <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs mb-4">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                      Head Coach
                    </span>
                    <span className="text-slate-200 font-medium truncate block">{team.coach}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                      Captain
                    </span>
                    <span className="text-slate-200 font-medium truncate block">{team.captain}</span>
                  </div>
                </div>

                {/* Performance pill stats */}
                <div className="flex items-center justify-between text-xs text-slate-400 px-1 py-1 border-t border-slate-800/60 mb-2">
                  <span>Record: <strong className="text-white">{team.wins}W - {team.draws}D - {team.losses}L</strong></span>
                  <span>Squad: <strong className="text-emerald-400">{squad.length} Players</strong></span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <button
                  onClick={() => setViewingTeam(team)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" /> View Profile
                </button>

                {userRole === 'ADMIN' && (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => openEditModal(team)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                      title="Edit Team"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(team)}
                      className="p-1.5 rounded-lg text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                      title="Delete Team"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-400" />
              {editingTeam ? 'Edit Team Details' : 'Register New Team'}
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Fill in club identity, coaching staff, and city headquarters.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Team ID *
                  </label>
                  <input
                    type="text"
                    value={formData.id}
                    disabled={!!editingTeam}
                    onChange={e => setFormData({ ...formData, id: e.target.value })}
                    placeholder="TM-07"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                  />
                  {formErrors.id && <p className="text-[11px] text-rose-400 mt-1">{formErrors.id}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    City / Region *
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Tokyo"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                  {formErrors.city && <p className="text-[11px] text-rose-400 mt-1">{formErrors.city}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Team Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Shiratorizawa Bulls"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
                {formErrors.name && <p className="text-[11px] text-rose-400 mt-1">{formErrors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Head Coach *
                  </label>
                  <input
                    type="text"
                    value={formData.coach}
                    onChange={e => setFormData({ ...formData, coach: e.target.value })}
                    placeholder="Coach Ukai"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                  {formErrors.coach && <p className="text-[11px] text-rose-400 mt-1">{formErrors.coach}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Team Captain *
                  </label>
                  <input
                    type="text"
                    value={formData.captain}
                    onChange={e => setFormData({ ...formData, captain: e.target.value })}
                    placeholder="Daichi Sawamura"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                  {formErrors.captain && <p className="text-[11px] text-rose-400 mt-1">{formErrors.captain}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Club Crest / Logo URL
                </label>
                <input
                  type="url"
                  value={formData.logo}
                  onChange={e => setFormData({ ...formData, logo: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Club Description
                </label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Tactical philosophy, formation preferences, and club background..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-950/50 transition-all"
                >
                  {editingTeam ? 'Save Changes' : 'Register Team'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Team Profile Modal (View Team) */}
      {viewingTeam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up space-y-6">
            <button
              onClick={() => setViewingTeam(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header info */}
            <div className="flex items-center gap-4">
              <img
                src={viewingTeam.logo}
                alt={viewingTeam.name}
                className="w-16 h-16 rounded-2xl object-cover bg-slate-800 border-2 border-emerald-500/40 shrink-0"
              />
              <div>
                <h2 className="text-xl font-bold text-white">{viewingTeam.name}</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Based in {viewingTeam.city} • Registered: {viewingTeam.registeredDate} • ID: {viewingTeam.id}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                    {viewingTeam.points} PTS
                  </span>
                  <span className="text-xs text-slate-400">
                    {viewingTeam.wins}W • {viewingTeam.draws}D • {viewingTeam.losses}L
                  </span>
                </div>
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-4 gap-3 p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Goals Scored</span>
                <p className="text-lg font-bold text-emerald-400">{viewingTeam.goalsFor}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Goals Conceded</span>
                <p className="text-lg font-bold text-rose-400">{viewingTeam.goalsAgainst}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Goal Difference</span>
                <p className="text-lg font-bold text-white font-mono">
                  {viewingTeam.goalsFor - viewingTeam.goalsAgainst > 0 ? `+${viewingTeam.goalsFor - viewingTeam.goalsAgainst}` : viewingTeam.goalsFor - viewingTeam.goalsAgainst}
                </p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Squad Size</span>
                <p className="text-lg font-bold text-cyan-400">
                  {players.filter(p => p.teamId === viewingTeam.id).length} Players
                </p>
              </div>
            </div>

            {/* Staff & Description */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Club Management</h4>
              <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-xs">
                <div>
                  <span className="text-slate-500 font-semibold block">Head Coach:</span>
                  <span className="text-white font-medium">{viewingTeam.coach}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-semibold block">Team Captain:</span>
                  <span className="text-white font-medium">{viewingTeam.captain}</span>
                </div>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/30 p-3 rounded-xl border border-slate-800/60">
                {viewingTeam.description || 'No detailed tactical bio provided for this club.'}
              </p>
            </div>

            {/* Squad Roster */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Registered Roster</h4>
              <div className="divide-y divide-slate-800/80 rounded-xl bg-slate-950/60 border border-slate-800 overflow-hidden">
                {players.filter(p => p.teamId === viewingTeam.id).length === 0 ? (
                  <p className="p-4 text-xs text-slate-500 text-center">No players assigned to this roster yet.</p>
                ) : (
                  players
                    .filter(p => p.teamId === viewingTeam.id)
                    .map(player => (
                      <div key={player.id} className="p-3 flex items-center justify-between text-xs hover:bg-slate-800/40">
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-md bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center font-mono">
                            #{player.jerseyNumber}
                          </span>
                          <div>
                            <span className="font-semibold text-white block">{player.name}</span>
                            <span className="text-[11px] text-slate-400">{player.position} • Age {player.age}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-right">
                          <span className="text-emerald-400 font-semibold">{player.goals} Goals</span>
                          <span className="text-cyan-400 font-medium">{player.assists} Assists</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                            {player.status}
                          </span>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setViewingTeam(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
