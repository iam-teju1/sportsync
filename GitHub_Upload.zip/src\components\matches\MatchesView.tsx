import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  Search,
  Play,
  Edit2,
  XCircle,
  Trash2,
  Clock,
  MapPin,
  Award,
  Filter,
  X,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { Match, MatchStatus } from '../../types';
import { ValidateService } from '../../services/validateService';

interface MatchesViewProps {
  onOpenConfirmation: (title: string, msg: string, onConfirm: () => void) => void;
  selectedMatchId?: string;
}

export const MatchesView: React.FC<MatchesViewProps> = ({ onOpenConfirmation, selectedMatchId }) => {
  const {
    matches,
    teams,
    venues,
    referees,
    userRole,
    scheduleMatch,
    updateMatch,
    recordScore,
    cancelMatch,
    deleteMatch
  } = useTournament();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals state
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isScoreModalOpen, setIsScoreModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);

  // Scheduling Form
  const [scheduleData, setScheduleData] = useState({
    id: '',
    homeTeamId: teams[0]?.id || '',
    awayTeamId: teams[1]?.id || '',
    venueId: venues[0]?.id || '',
    refereeId: referees[0]?.id || '',
    date: new Date().toISOString().substring(0, 10),
    time: '18:00',
    status: 'Scheduled' as MatchStatus
  });

  // Score Form
  const [scoreData, setScoreData] = useState({
    homeScore: 0,
    awayScore: 0
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredMatches = matches
    .filter(m => {
      const home = teams.find(t => t.id === m.homeTeamId)?.name || '';
      const away = teams.find(t => t.id === m.awayTeamId)?.name || '';
      const venue = venues.find(v => v.id === m.venueId)?.name || '';
      const ref = referees.find(r => r.id === m.refereeId)?.name || '';

      const matchesSearch =
        m.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        home.toLowerCase().includes(searchTerm.toLowerCase()) ||
        away.toLowerCase().includes(searchTerm.toLowerCase()) ||
        venue.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ref.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.date.includes(searchTerm);

      const matchesStatus = statusFilter === 'ALL' || m.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));

  // Open Schedule Modal
  const openScheduleModal = () => {
    setScheduleData({
      id: `MT-${matches.length + 1 < 10 ? '0' : ''}${matches.length + 1}`,
      homeTeamId: teams[0]?.id || '',
      awayTeamId: teams[1]?.id || '',
      venueId: venues[0]?.id || '',
      refereeId: referees[0]?.id || '',
      date: new Date().toISOString().substring(0, 10),
      time: '18:00',
      status: 'Scheduled'
    });
    setFormErrors({});
    setIsScheduleModalOpen(true);
  };

  // Open Score Recording Modal
  const openScoreModal = (match: Match) => {
    setActiveMatch(match);
    setScoreData({
      homeScore: match.homeScore || 0,
      awayScore: match.awayScore || 0
    });
    setFormErrors({});
    setIsScoreModalOpen(true);
  };

  // Open Edit Modal (Checking completed status protection)
  const openEditModal = (match: Match) => {
    setActiveMatch(match);
    setScheduleData({
      id: match.id,
      homeTeamId: match.homeTeamId,
      awayTeamId: match.awayTeamId,
      venueId: match.venueId,
      refereeId: match.refereeId,
      date: match.date,
      time: match.time,
      status: match.status
    });
    setFormErrors({});

    if (match.status === 'Completed') {
      onOpenConfirmation(
        'Edit Completed Match Warning',
        `Match ${match.id} has already concluded and its score is factored into tournament standings. Editing schedule parameters requires administrator confirmation. Do you wish to continue?`,
        () => setIsEditModalOpen(true)
      );
    } else {
      setIsEditModalOpen(true);
    }
  };

  // Handle Match Scheduling
  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = ValidateService.validateMatch(
      scheduleData,
      matches,
      venues,
      referees,
      false
    );

    if (!val.isValid) {
      setFormErrors(val.errors);
      return;
    }

    const res = await scheduleMatch(scheduleData);
    if (res.success) {
      setIsScheduleModalOpen(false);
    }
  };

  // Handle Match Updating
  const handleUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMatch) return;

    const updated: Match = {
      ...activeMatch,
      ...scheduleData
    };

    const val = ValidateService.validateMatch(
      updated,
      matches,
      venues,
      referees,
      true
    );

    if (!val.isValid) {
      setFormErrors(val.errors);
      return;
    }

    const res = await updateMatch(updated);
    if (res.success) {
      setIsEditModalOpen(false);
    }
  };

  // Handle Score Record
  const handleScoreSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMatch) return;

    const res = await recordScore(activeMatch.id, scoreData.homeScore, scoreData.awayScore);
    if (res.success) {
      setIsScoreModalOpen(false);
    }
  };

  const getStatusBadge = (status: MatchStatus) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      case 'Scheduled':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'Live':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse';
      case 'Cancelled':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <Calendar className="w-6 h-6 text-amber-400" />
            Match Fixtures & Results
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Automated conflict-preventing scheduler, live scoreboard, and completed match records.
          </p>
        </div>

        {userRole === 'ADMIN' && (
          <button
            onClick={openScheduleModal}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all self-start sm:self-center shrink-0"
          >
            <Plus className="w-4 h-4" /> Schedule Match
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search match, club, venue, referee, date..."
              className="pl-9 pr-4 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 w-60 sm:w-72"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Status:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        <span className="text-slate-400 font-medium">
          Total: <strong>{filteredMatches.length}</strong> fixtures
        </span>
      </div>

      {/* Matches List */}
      <div className="space-y-4">
        {filteredMatches.map(match => {
          const homeTeam = teams.find(t => t.id === match.homeTeamId);
          const awayTeam = teams.find(t => t.id === match.awayTeamId);
          const venue = venues.find(v => v.id === match.venueId);
          const referee = referees.find(r => r.id === match.refereeId);
          const isCompleted = match.status === 'Completed';

          return (
            <div
              key={match.id}
              className={`p-5 rounded-2xl bg-slate-900/90 border transition-all duration-200 shadow-xl ${
                isCompleted ? 'border-slate-800' : 'border-slate-800 hover:border-amber-500/40'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                {/* Left: Match Meta */}
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center min-w-[70px]">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">
                      {match.date.substring(5)}
                    </span>
                    <span className="text-xs font-black text-white font-mono mt-0.5 block">
                      {match.time}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 font-mono">
                        {match.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(match.status)}`}>
                        {match.status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-emerald-400" />
                        {venue ? `${venue.name} (${venue.city})` : 'Unknown Venue'}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Award className="w-3 h-3 text-rose-400" />
                        Ref: {referee ? referee.name : 'Unassigned'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Center: Teams & Scoreboard */}
                <div className="flex items-center justify-center gap-4 sm:gap-8 flex-1 max-w-xl mx-auto">
                  {/* Home Team */}
                  <div className="flex items-center gap-3 justify-end flex-1 text-right">
                    <span className="font-bold text-sm sm:text-base text-white tracking-tight">
                      {homeTeam ? homeTeam.name : match.homeTeamId}
                    </span>
                    <img
                      src={homeTeam?.logo}
                      alt={homeTeam?.name}
                      className="w-10 h-10 rounded-xl object-cover bg-slate-800 border border-slate-700 shrink-0"
                      onError={e => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=64';
                      }}
                    />
                  </div>

                  {/* Score or VS Badge */}
                  <div className="shrink-0 px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 min-w-[90px] text-center shadow-inner">
                    {isCompleted ? (
                      <span className="text-xl sm:text-2xl font-black text-white font-mono tracking-widest">
                        {match.homeScore} : {match.awayScore}
                      </span>
                    ) : (
                      <span className="text-xs font-black uppercase text-amber-400 tracking-wider">
                        VS
                      </span>
                    )}
                  </div>

                  {/* Away Team */}
                  <div className="flex items-center gap-3 justify-start flex-1 text-left">
                    <img
                      src={awayTeam?.logo}
                      alt={awayTeam?.name}
                      className="w-10 h-10 rounded-xl object-cover bg-slate-800 border border-slate-700 shrink-0"
                      onError={e => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=64';
                      }}
                    />
                    <span className="font-bold text-sm sm:text-base text-white tracking-tight">
                      {awayTeam ? awayTeam.name : match.awayTeamId}
                    </span>
                  </div>
                </div>

                {/* Right: Actions */}
                {userRole === 'ADMIN' && (
                  <div className="flex items-center justify-end gap-2 shrink-0">
                    {match.status === 'Scheduled' && (
                      <button
                        onClick={() => openScoreModal(match)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-950/40 flex items-center gap-1.5 transition-colors"
                      >
                        <Play className="w-3.5 h-3.5" /> Record Score
                      </button>
                    )}

                    {match.status === 'Completed' && (
                      <button
                        onClick={() => openScoreModal(match)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
                        title="Update Final Score"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-amber-400" /> Edit Score
                      </button>
                    )}

                    <button
                      onClick={() => openEditModal(match)}
                      className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                      title="Edit Match Info"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {match.status !== 'Cancelled' && (
                      <button
                        onClick={() =>
                          onOpenConfirmation(
                            'Cancel Fixture',
                            `Are you sure you want to mark Match ${match.id} as Cancelled?`,
                            () => cancelMatch(match.id)
                          )
                        }
                        className="p-2 rounded-xl text-amber-400/80 hover:text-amber-400 hover:bg-amber-950/40 transition-colors"
                        title="Cancel Match"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    )}

                    <button
                      onClick={() =>
                        onOpenConfirmation(
                          'Delete Match Record',
                          `Are you sure you want to permanently delete Match ${match.id}?`,
                          () => deleteMatch(match.id)
                        )
                      }
                      className="p-2 rounded-xl text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                      title="Delete Match"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Schedule Match Modal */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up">
            <button
              onClick={() => setIsScheduleModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-400" />
              Schedule Tournament Fixture
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Automatic validation ensures venues and referees cannot be double booked at the same time.
            </p>

            <form onSubmit={handleScheduleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Match ID *
                </label>
                <input
                  type="text"
                  value={scheduleData.id}
                  onChange={e => setScheduleData({ ...scheduleData, id: e.target.value })}
                  placeholder="MT-19"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                {formErrors.id && <p className="text-[11px] text-rose-400 mt-1">{formErrors.id}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Home Team *
                  </label>
                  <select
                    value={scheduleData.homeTeamId}
                    onChange={e => setScheduleData({ ...scheduleData, homeTeamId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {teams.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.homeTeamId && <p className="text-[11px] text-rose-400 mt-1">{formErrors.homeTeamId}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Away Team *
                  </label>
                  <select
                    value={scheduleData.awayTeamId}
                    onChange={e => setScheduleData({ ...scheduleData, awayTeamId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {teams.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.awayTeamId && <p className="text-[11px] text-rose-400 mt-1">{formErrors.awayTeamId}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Stadium Venue *
                  </label>
                  <select
                    value={scheduleData.venueId}
                    onChange={e => setScheduleData({ ...scheduleData, venueId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {venues.map(v => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.city})
                      </option>
                    ))}
                  </select>
                  {formErrors.venueId && <p className="text-[11px] text-rose-400 mt-1">{formErrors.venueId}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Officiating Referee *
                  </label>
                  <select
                    value={scheduleData.refereeId}
                    onChange={e => setScheduleData({ ...scheduleData, refereeId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {referees.map(r => (
                      <option key={r.id} value={r.id}>
                        {r.name} ({r.experience} yrs)
                      </option>
                    ))}
                  </select>
                  {formErrors.refereeId && <p className="text-[11px] text-rose-400 mt-1">{formErrors.refereeId}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    value={scheduleData.date}
                    onChange={e => setScheduleData({ ...scheduleData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  />
                  {formErrors.date && <p className="text-[11px] text-rose-400 mt-1">{formErrors.date}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Kickoff Time *
                  </label>
                  <input
                    type="time"
                    value={scheduleData.time}
                    onChange={e => setScheduleData({ ...scheduleData, time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  />
                  {formErrors.time && <p className="text-[11px] text-rose-400 mt-1">{formErrors.time}</p>}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 shadow-lg shadow-amber-950/50"
                >
                  Schedule Match
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Score Modal */}
      {isScoreModalOpen && activeMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl relative animate-slide-up">
            <button
              onClick={() => setIsScoreModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Play className="w-5 h-5 text-emerald-400" />
              Record Official Match Score
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Match {activeMatch.id} • Points table and team records will update automatically upon confirmation.
            </p>

            <form onSubmit={handleScoreSubmit} className="space-y-6">
              <div className="flex items-center justify-between gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
                {/* Home */}
                <div className="flex-1">
                  <span className="text-xs font-bold text-white block mb-2 truncate">
                    {teams.find(t => t.id === activeMatch.homeTeamId)?.name}
                  </span>
                  <input
                    type="number"
                    min={0}
                    max={99}
                    value={scoreData.homeScore}
                    onChange={e => setScoreData({ ...scoreData, homeScore: parseInt(e.target.value) || 0 })}
                    className="w-20 text-center py-2 text-2xl font-black font-mono text-emerald-400 bg-slate-900 border border-slate-700 rounded-xl mx-auto focus:outline-none focus:border-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block mt-1">Home Goals</span>
                </div>

                <span className="text-xl font-black text-slate-600">:</span>

                {/* Away */}
                <div className="flex-1">
                  <span className="text-xs font-bold text-white block mb-2 truncate">
                    {teams.find(t => t.id === activeMatch.awayTeamId)?.name}
                  </span>
                  <input
                    type="number"
                    min={0}
                    max={99}
                    value={scoreData.awayScore}
                    onChange={e => setScoreData({ ...scoreData, awayScore: parseInt(e.target.value) || 0 })}
                    className="w-20 text-center py-2 text-2xl font-black font-mono text-emerald-400 bg-slate-900 border border-slate-700 rounded-xl mx-auto focus:outline-none focus:border-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block mt-1">Away Goals</span>
                </div>
              </div>

              {/* Projected Points Impact preview */}
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 text-center">
                {scoreData.homeScore > scoreData.awayScore ? (
                  <span>Outcome: <strong className="text-emerald-400">Home Win</strong> (+3 Pts)</span>
                ) : scoreData.awayScore > scoreData.homeScore ? (
                  <span>Outcome: <strong className="text-cyan-400">Away Win</strong> (+3 Pts)</span>
                ) : (
                  <span>Outcome: <strong className="text-amber-400">Draw</strong> (+1 Pt each)</span>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsScoreModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-950/50"
                >
                  Save & Update Standings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Match Info Modal */}
      {isEditModalOpen && activeMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto animate-slide-up">
            <button
              onClick={() => setIsEditModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Edit2 className="w-5 h-5 text-amber-400" />
              Edit Match Details ({activeMatch.id})
            </h2>

            <form onSubmit={handleUpdateSubmit} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Stadium Venue *
                  </label>
                  <select
                    value={scheduleData.venueId}
                    onChange={e => setScheduleData({ ...scheduleData, venueId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {venues.map(v => (
                      <option key={v.id} value={v.id}>
                        {v.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Referee *
                  </label>
                  <select
                    value={scheduleData.refereeId}
                    onChange={e => setScheduleData({ ...scheduleData, refereeId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-500"
                  >
                    {referees.map(r => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Date *</label>
                  <input
                    type="date"
                    value={scheduleData.date}
                    onChange={e => setScheduleData({ ...scheduleData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Time *</label>
                  <input
                    type="time"
                    value={scheduleData.time}
                    onChange={e => setScheduleData({ ...scheduleData, time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Status</label>
                <select
                  value={scheduleData.status}
                  onChange={e => setScheduleData({ ...scheduleData, status: e.target.value as MatchStatus })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"
                >
                  <option value="Scheduled">Scheduled</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 shadow-lg"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
