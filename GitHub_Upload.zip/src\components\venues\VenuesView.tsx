import React, { useState } from 'react';
import {
  MapPin,
  Plus,
  Search,
  Edit2,
  Trash2,
  Calendar,
  Building2,
  X,
  CheckCircle2,
  Clock,
  AlertTriangle
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { Venue, VenueAvailability } from '../../types';
import { ValidateService } from '../../services/validateService';

interface VenuesViewProps {
  onOpenConfirmation: (title: string, msg: string, onConfirm: () => void) => void;
  selectedVenueId?: string;
}

export const VenuesView: React.FC<VenuesViewProps> = ({ onOpenConfirmation, selectedVenueId }) => {
  const { venues, matches, teams, userRole, addVenue, updateVenue, deleteVenue } = useTournament();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVenue, setEditingVenue] = useState<Venue | null>(null);
  const [selectedCalendarVenue, setSelectedCalendarVenue] = useState<Venue | null>(
    selectedVenueId ? venues.find(v => v.id === selectedVenueId) || venues[0] || null : venues[0] || null
  );

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    address: '',
    city: '',
    capacity: 35000,
    availability: 'Available' as VenueAvailability
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredVenues = venues.filter(v =>
    v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openAddModal = () => {
    setEditingVenue(null);
    setFormData({
      id: `VN-0${venues.length + 1}`,
      name: '',
      address: '',
      city: '',
      capacity: 35000,
      availability: 'Available'
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const openEditModal = (venue: Venue) => {
    setEditingVenue(venue);
    setFormData({
      id: venue.id,
      name: venue.name,
      address: venue.address,
      city: venue.city,
      capacity: venue.capacity,
      availability: venue.availability
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingVenue) {
      const updated: Venue = { ...editingVenue, ...formData };
      const val = ValidateService.validateVenue(updated, venues, true);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await updateVenue(updated);
      if (res.success) setIsModalOpen(false);
    } else {
      const val = ValidateService.validateVenue(formData, venues, false);
      if (!val.isValid) {
        setFormErrors(val.errors);
        return;
      }
      const res = await addVenue(formData);
      if (res.success) setIsModalOpen(false);
    }
  };

  const handleDelete = (venue: Venue) => {
    onOpenConfirmation(
      'Delete Venue',
      `Are you sure you want to delete ${venue.name}? Any matches currently scheduled at this stadium will need reassignment.`,
      () => deleteVenue(venue.id)
    );
  };

  const venueMatches = selectedCalendarVenue
    ? matches.filter(m => m.venueId === selectedCalendarVenue.id)
    : [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <Building2 className="w-6 h-6 text-purple-400" />
            Tournament Venues & Stadiums
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Stadium capacity, booking availability calendar, and physical facility management.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search stadiums, cities..."
              className="pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 w-52 sm:w-60"
            />
          </div>

          {userRole === 'ADMIN' && (
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Venue
            </button>
          )}
        </div>
      </div>

      {/* Venues Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredVenues.map(venue => {
          const matchCount = matches.filter(m => m.venueId === venue.id).length;
          const isSelected = selectedCalendarVenue?.id === venue.id;

          return (
            <div
              key={venue.id}
              onClick={() => setSelectedCalendarVenue(venue)}
              className={`p-5 rounded-2xl bg-slate-900/90 border transition-all duration-200 cursor-pointer shadow-xl flex flex-col justify-between ${
                isSelected ? 'border-purple-500 ring-2 ring-purple-500/20' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 font-mono">{venue.id}</span>
                    <h3 className="text-base font-bold text-white tracking-tight mt-0.5">{venue.name}</h3>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      venue.availability === 'Available'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : venue.availability === 'Booked'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}
                  >
                    {venue.availability}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-400 mb-4">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>{venue.address}, {venue.city}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>Capacity: <strong className="text-white">{venue.capacity.toLocaleString()}</strong> seats</span>
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center text-xs">
                  <span className="text-slate-400">Allocated Matches: </span>
                  <strong className="text-purple-400 font-bold">{matchCount} Fixtures</strong>
                </div>
              </div>

              {userRole === 'ADMIN' && (
                <div className="flex items-center justify-end gap-1.5 pt-3 mt-4 border-t border-slate-800">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      openEditModal(venue);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      handleDelete(venue);
                    }}
                    className="p-1.5 rounded-lg text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Availability Calendar & Schedule Matrix */}
      {selectedCalendarVenue && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-400" />
                Availability Calendar: {selectedCalendarVenue.name}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time booking matrix showing all confirmed match slots at {selectedCalendarVenue.city}.
              </p>
            </div>
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 self-start">
              Capacity: {selectedCalendarVenue.capacity.toLocaleString()} spectators
            </span>
          </div>

          <div className="space-y-2.5">
            {venueMatches.length === 0 ? (
              <p className="text-xs text-slate-500 py-8 text-center">
                No fixtures currently booked for this stadium. It is fully available for scheduling.
              </p>
            ) : (
              venueMatches.map(m => {
                const home = teams.find(t => t.id === m.homeTeamId)?.name;
                const away = teams.find(t => t.id === m.awayTeamId)?.name;

                return (
                  <div
                    key={m.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition-colors text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 font-mono font-bold text-purple-400">
                        {m.date} • {m.time}
                      </div>
                      <span className="font-semibold text-white">
                        {home} vs {away}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">Match ID: {m.id}</span>
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          m.status === 'Completed'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {m.status}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative animate-slide-up">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-purple-400" />
              {editingVenue ? 'Edit Stadium Venue' : 'Register New Venue'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Venue ID *
                  </label>
                  <input
                    type="text"
                    value={formData.id}
                    disabled={!!editingVenue}
                    onChange={e => setFormData({ ...formData, id: e.target.value })}
                    placeholder="VN-05"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500 disabled:opacity-50"
                  />
                  {formErrors.id && <p className="text-[11px] text-rose-400 mt-1">{formErrors.id}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Capacity (Seats) *
                  </label>
                  <input
                    type="number"
                    value={formData.capacity}
                    onChange={e => setFormData({ ...formData, capacity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                  {formErrors.capacity && <p className="text-[11px] text-rose-400 mt-1">{formErrors.capacity}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Venue Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Sakura Arena"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500"
                />
                {formErrors.name && <p className="text-[11px] text-rose-400 mt-1">{formErrors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    Street Address *
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                    placeholder="1-1 Sakuragaoka, Shibuya"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                  {formErrors.address && <p className="text-[11px] text-rose-400 mt-1">{formErrors.address}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Tokyo"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                  {formErrors.city && <p className="text-[11px] text-rose-400 mt-1">{formErrors.city}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">
                  Availability Status
                </label>
                <select
                  value={formData.availability}
                  onChange={e => setFormData({ ...formData, availability: e.target.value as VenueAvailability })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="Available">Available</option>
                  <option value="Booked">Booked</option>
                  <option value="Maintenance">Maintenance</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 shadow-lg"
                >
                  {editingVenue ? 'Save Changes' : 'Register Venue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
