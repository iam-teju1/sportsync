import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  FileText,
  Table,
  CheckCircle2,
  Calendar,
  Users,
  Building2,
  Award,
  Sparkles
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import { ReportService, ReportType, ReportData } from '../../services/reportService';

export const ReportsView: React.FC = () => {
  const { teams, players, matches, venues, referees, addToast } = useTournament();
  const [selectedReport, setSelectedReport] = useState<ReportType>('TOURNAMENT_SUMMARY');

  const reportConfigs: { id: ReportType; label: string; icon: any; desc: string }[] = [
    { id: 'TOURNAMENT_SUMMARY', label: 'Executive Summary', icon: Sparkles, desc: 'High-level tournament KPIs, champions, awards and averages' },
    { id: 'POINTS_TABLE', label: 'Points Table', icon: Table, desc: 'Official standings, points, goal differences, and form' },
    { id: 'FIXTURES', label: 'Upcoming Fixtures', icon: Calendar, desc: 'Schedule of upcoming matches by date and venue' },
    { id: 'MATCH_RESULTS', label: 'Match Results', icon: CheckCircle2, desc: 'Scores and official logs of completed tournament matches' },
    { id: 'PLAYERS', label: 'Player Statistics', icon: Users, desc: 'Golden Boot, assist leaders, disciplinary cards, squad rosters' },
    { id: 'TEAMS', label: 'Club Management', icon: Users, desc: 'Team head coaches, captains, home cities, and club records' },
    { id: 'VENUES', label: 'Stadium Facilities', icon: Building2, desc: 'Venue capacities, match distribution, and availability' },
    { id: 'REFEREES', label: 'Officiating Roster', icon: Award, desc: 'Referee assignments, credentials, and contact profiles' },
  ];

  const getReportData = (type: ReportType): ReportData => {
    switch (type) {
      case 'POINTS_TABLE':
        return ReportService.generatePointsTableReport(teams, matches);
      case 'FIXTURES':
        return ReportService.generateFixtureReport(matches, teams, venues, referees);
      case 'MATCH_RESULTS':
        return ReportService.generateMatchReport(matches, teams, venues, referees);
      case 'PLAYERS':
        return ReportService.generatePlayerReport(players, teams);
      case 'TEAMS':
        return ReportService.generateTeamReport(teams, players);
      case 'VENUES':
        return ReportService.generateVenueReport(venues, matches);
      case 'REFEREES':
        return ReportService.generateRefereeReport(referees, matches);
      case 'TOURNAMENT_SUMMARY':
      default:
        return ReportService.generateTournamentSummaryReport(teams, players, matches, venues, referees);
    }
  };

  const currentReportData = getReportData(selectedReport);

  const handleExportCSV = () => {
    ReportService.exportToCSV(`SportSync_${selectedReport}`, currentReportData.headers, currentReportData.rows);
    addToast('success', 'CSV Exported', `${currentReportData.title} saved to CSV.`);
  };

  const handleExportPDF = () => {
    ReportService.exportToPDF(
      currentReportData.title,
      currentReportData.subtitle,
      currentReportData.headers,
      currentReportData.rows,
      `SportSync_${selectedReport}`
    );
    addToast('success', 'PDF Generated', `${currentReportData.title} downloaded as PDF.`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 font-display">
            <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
            Official Report Generation & Export
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Generate and export publication-ready reports for all 8 tournament modules in PDF and CSV format.
          </p>
        </div>

        {/* Global Export actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center gap-2 transition-all shadow-md"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" /> Export CSV
          </button>
          <button
            onClick={handleExportPDF}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/50 flex items-center gap-2 transition-all"
          >
            <FileText className="w-3.5 h-3.5" /> Download PDF Report
          </button>
        </div>
      </div>

      {/* Report Selection Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {reportConfigs.map(cfg => {
          const Icon = cfg.icon;
          const isSelected = selectedReport === cfg.id;

          return (
            <button
              key={cfg.id}
              onClick={() => setSelectedReport(cfg.id)}
              className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-emerald-500/10 border-emerald-500 text-white shadow-lg shadow-emerald-950/30'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`p-2 rounded-xl ${isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-950 text-slate-400'}`}>
                  <Icon className="w-4 h-4" />
                </div>
                {isSelected && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold text-white tracking-tight">{cfg.label}</h4>
                <p className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">{cfg.desc}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Report Preview Panel */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Report Title & Subtitle banner */}
        <div className="p-5 sm:p-6 bg-slate-950/70 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block mb-1">
              Live Report Preview
            </span>
            <h2 className="text-lg font-bold text-white">{currentReportData.title}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{currentReportData.subtitle}</p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
              {currentReportData.rows.length} Records
            </span>
          </div>
        </div>

        {/* Scrollable Preview Table */}
        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-slate-950 border-b border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <tr>
                {currentReportData.headers.map((h, i) => (
                  <th key={i} className="py-3 px-4">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs text-slate-200">
              {currentReportData.rows.map((row, rIdx) => (
                <tr key={rIdx} className="hover:bg-slate-800/40 transition-colors">
                  {row.map((cell, cIdx) => (
                    <td key={cIdx} className="py-3 px-4">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Bottom banner */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>Official SportSync Certification • Validated automatically</span>
          <div className="flex gap-2">
            <button
              onClick={handleExportCSV}
              className="hover:text-emerald-400 font-semibold"
            >
              Export CSV →
            </button>
            <span>•</span>
            <button
              onClick={handleExportPDF}
              className="hover:text-emerald-400 font-semibold"
            >
              Export PDF →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
