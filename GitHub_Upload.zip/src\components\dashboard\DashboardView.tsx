import React from 'react';
import {
  Users,
  UserCheck,
  Calendar,
  Clock,
  CheckCircle2,
  MapPin,
  Award,
  TrendingUp,
  Activity,
  Plus,
  Play,
  FileText,
  AlertCircle,
  Trophy,
  Flame
} from 'lucide-react';
import { useTournament } from '../../context/TournamentContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  AreaChart,
  Area
} from 'recharts';

interface DashboardViewProps {
  onNavigate: (tab: string) => void;
  onOpenSchedule: () => void;
  onOpenRecordScore: () => void;
  onOpenAddTeam: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenSchedule,
  onOpenRecordScore,
  onOpenAddTeam
}) => {
  const {
    teams,
    players,
    matches,
    venues,
    referees,
    activities,
    standings,
    analytics,
    userRole
  } = useTournament();

  const availableVenuesCount = venues.filter(v => v.availability === 'Available').length;
  const activeRefereesCount = referees.filter(r => r.status === 'Active').length;

  const statCards = [
    {
      title: 'Total Teams',
      value: teams.length,
      icon: Users,
      color: 'from-emerald-500/20 to-emerald-950/40 text-emerald-400 border-emerald-500/30',
      action: () => onNavigate('teams')
    },
    {
      title: 'Total Players',
      value: players.length,
      icon: UserCheck,
      color: 'from-cyan-500/20 to-cyan-950/40 text-cyan-400 border-cyan-500/30',
      action: () => onNavigate('players')
    },
    {
      title: 'Total Matches',
      value: matches.length,
      icon: Calendar,
      color: 'from-blue-500/20 to-blue-950/40 text-blue-400 border-blue-500/30',
      action: () => onNavigate('matches')
    },
    {
      title: 'Upcoming Matches',
      value: analytics.upcomingMatches,
      icon: Clock,
      color: 'from-amber-500/20 to-amber-950/40 text-amber-400 border-amber-500/30',
      action: () => onNavigate('matches')
    },
    {
      title: 'Completed Matches',
      value: analytics.completedMatches,
      icon: CheckCircle2,
      color: 'from-purple-500/20 to-purple-950/40 text-purple-400 border-purple-500/30',
      action: () => onNavigate('matches')
    },
    {
      title: 'Available Venues',
      value: `${availableVenuesCount} / ${venues.length}`,
      icon: MapPin,
      color: 'from-teal-500/20 to-teal-950/40 text-teal-400 border-teal-500/30',
      action: () => onNavigate('venues')
    },
    {
      title: 'Active Referees',
      value: `${activeRefereesCount} / ${referees.length}`,
      icon: Award,
      color: 'from-rose-500/20 to-rose-950/40 text-rose-400 border-rose-500/30',
      action: () => onNavigate('referees')
    },
    {
      title: 'Tournament Status',
      value: 'IN PROGRESS',
      isBadge: true,
      icon: Trophy,
      color: 'from-amber-500/20 to-amber-950/40 text-amber-300 border-amber-500/40',
      action: () => onNavigate('standings')
    }
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/50 to-slate-900 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              All-Japan Premier Championship 2026
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
              AI Sports Tournament Command Center
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Real-time match scheduling, automated standings recalculations, conflict-free referee & venue assignment, and AI-powered performance analysis.
            </p>
          </div>

          {/* Quick Actions (Admin Only or Disabled for Viewers) */}
          <div className="flex flex-wrap items-center gap-2.5">
            {userRole === 'ADMIN' ? (
              <>
                <button
                  onClick={onOpenSchedule}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
                >
                  <Plus className="w-4 h-4" /> Schedule Match
                </button>
                <button
                  onClick={onOpenRecordScore}
                  className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-cyan-950/50 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
                >
                  <Play className="w-4 h-4" /> Record Score
                </button>
                <button
                  onClick={onOpenAddTeam}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-xs sm:text-sm border border-slate-700 flex items-center gap-2 transition-all"
                >
                  <Users className="w-4 h-4 text-emerald-400" /> Add Team
                </button>
              </>
            ) : (
              <button
                onClick={() => onNavigate('reports')}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 flex items-center gap-2 transition-all"
              >
                <FileText className="w-4 h-4" /> View & Export Reports
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              onClick={card.action}
              className={`p-4 sm:p-5 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border transition-all duration-200 cursor-pointer shadow-lg group relative overflow-hidden ${card.color}`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
                  {card.title}
                </span>
                <div className="p-2 rounded-xl bg-slate-950/60 border border-white/10 group-hover:scale-110 transition-transform">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                {card.isBadge ? (
                  <span className="text-sm font-black px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    {card.value}
                  </span>
                ) : (
                  <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    {card.value}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Team Standings & Points */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                Team Points & Performance
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Current league points tally based on completed matches (Win=3, Draw=1)
              </p>
            </div>
            <button
              onClick={() => onNavigate('standings')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              Full Table →
            </button>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={standings} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis
                  dataKey="teamName"
                  stroke="#64748b"
                  fontSize={10}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#fff'
                  }}
                />
                <Bar dataKey="points" name="Points" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Goal Distribution (Goals For vs Goals Against) */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                Goal Distribution (GF vs GA)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Attacking output vs defensive record across tournament squads
              </p>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              Avg: {analytics.averageGoalsPerMatch} Goals/Match
            </span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.goalDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis
                  dataKey="teamName"
                  stroke="#64748b"
                  fontSize={10}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#fff'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="goalsFor" name="Goals Scored" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                <Bar dataKey="goalsAgainst" name="Goals Conceded" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Activities & Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Tournament Activities */}
        <div className="lg:col-span-2 p-5 sm:p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              Recent Tournament Activities
            </h3>
            <span className="text-xs text-slate-500">Live feed</span>
          </div>

          <div className="space-y-3">
            {activities.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No recent activities logged yet.</p>
            ) : (
              activities.slice(0, 5).map(act => (
                <div
                  key={act.id}
                  className="flex items-start gap-3.5 p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition-colors"
                >
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0 mt-0.5">
                    {act.actionType === 'MATCH_SCORE' ? (
                      <Trophy className="w-4 h-4 text-emerald-400" />
                    ) : act.actionType === 'MATCH_SCHEDULED' ? (
                      <Calendar className="w-4 h-4 text-amber-400" />
                    ) : act.actionType === 'PLAYER_ADDED' ? (
                      <UserCheck className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <Users className="w-4 h-4 text-purple-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs sm:text-sm font-semibold text-white truncate">
                        {act.title}
                      </h4>
                      <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                        {act.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                      {act.description}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right 1 Col: Tournament Highlights & Notifications */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2 mb-3">
              <Trophy className="w-4 h-4 text-amber-400" />
              Tournament Spotlight
            </h3>

            <div className="space-y-3">
              {/* Champion Leader */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30">
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block mb-1">
                  1st Place (Title Favorite)
                </span>
                <p className="text-sm font-bold text-white">
                  {analytics.champion?.name || 'In Progress'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {analytics.champion?.points || 0} Points • {analytics.champion?.wins || 0} Wins
                </p>
              </div>

              {/* Golden Boot Leader */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-500/10 via-slate-900 to-slate-900 border border-emerald-500/30">
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 block mb-1">
                  Golden Boot Leader
                </span>
                <p className="text-sm font-bold text-white">
                  {analytics.topScorer ? `${analytics.topScorer.player.name}` : 'N/A'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {analytics.topScorer ? `${analytics.topScorer.player.goals} Goals • ${analytics.topScorer.teamName}` : 'No goals yet'}
                </p>
              </div>

              {/* MVP Leader */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-cyan-500/10 via-slate-900 to-slate-900 border border-cyan-500/30">
                <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400 block mb-1">
                  Tournament MVP Candidate
                </span>
                <p className="text-sm font-bold text-white">
                  {analytics.mvp ? analytics.mvp.player.name : 'N/A'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {analytics.mvp ? `Impact Index: ${analytics.mvp.rating} • ${analytics.mvp.teamName}` : 'Evaluating'}
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('analytics')}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold text-center transition-colors border border-slate-700"
          >
            Explore AI Insights & Deep Stats →
          </button>
        </div>
      </div>
    </div>
  );
};
